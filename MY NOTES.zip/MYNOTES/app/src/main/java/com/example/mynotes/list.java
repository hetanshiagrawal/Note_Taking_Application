package com.example.mynotes;

public class list<T> {
}
